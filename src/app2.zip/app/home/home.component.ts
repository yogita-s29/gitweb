import { Component, OnInit } from '@angular/core';



@Component({

  selector: 'app-home',

  template: '<div><span>Welcome to {{title}}!!!</span></div>',

  styleUrls: ['./home.component.css']

})

export class HomeComponent implements OnInit {



  title:string="Mauli";



  constructor() { }



  ngOnInit(): void {

  }



}